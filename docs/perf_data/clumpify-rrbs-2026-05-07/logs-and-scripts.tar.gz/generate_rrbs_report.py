#!/usr/bin/env python3
"""
Generate clumpify benchmark report on RRBS PE — with WGBS comparison section.

Inputs:  /tmp/claude/clumpify_rrbs_results/results/summary.csv
         /tmp/claude/clumpify_results/results/summary.csv  (WGBS reference)
Outputs: /tmp/claude/clumpify_rrbs_results/REPORT.md
         /tmp/claude/clumpify_rrbs_results/plots/*.png
"""
import os
import re
import csv
from pathlib import Path
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path("/tmp/claude/clumpify_rrbs_results")
RESULTS = ROOT / "results"
PLOTS = ROOT / "plots"
PLOTS.mkdir(exist_ok=True)

# ─── Load both fixtures ──────────────────────────────────────────────────
def load_csv(p):
    rows = []
    with open(p) as f:
        for r in csv.DictReader(f):
            r["wall"] = float(r["wall_mean_s"])
            r["cpu_user"] = float(r["cpu_user_s"])
            r["cpu_sys"] = float(r["cpu_sys_s"])
            r["rss_mib"] = float(r["peak_rss_kib"]) / 1024.0
            r["out_gib"] = float(r["out_bytes"]) / (1024**3)
            rows.append(r)
    ref = next(r for r in rows if r["label"] == "C_plain_c1")["out_gib"]
    for r in rows:
        r["saving_pct"] = (ref - r["out_gib"]) / ref * 100
    return rows, ref


rrbs_rows, RRBS_REF = load_csv(RESULTS / "summary.csv")
wgbs_rows, WGBS_REF = load_csv("/tmp/claude/clumpify_results/results/summary.csv")


def by_prefix(rows, prefix):
    return [r for r in rows if r["label"].startswith(prefix)]


def lvl(r):
    m = re.search(r"_c(\d+)(?:_|$)", r["label"])
    return int(m.group(1)) if m else None


def mem_of(r):
    m = re.search(r"_m(\d+G)$", r["label"])
    return m.group(1) if m else None


mem_order = ["1G", "2G", "4G", "8G", "16G"]
mem_ints = {"1G": 1, "2G": 2, "4G": 4, "8G": 8, "16G": 16}


def lanes(rows):
    return (
        sorted(by_prefix(rows, "A_clumpify_c1_"), key=lambda r: mem_order.index(mem_of(r))),
        sorted([r for r in by_prefix(rows, "B_clumpify_") if "_c" in r["label"]], key=lvl),
        sorted(by_prefix(rows, "C_plain_"), key=lvl),
    )


a_rrbs, b_rrbs, c_rrbs = lanes(rrbs_rows)
a_wgbs, b_wgbs, c_wgbs = lanes(wgbs_rows)

# ─── Plot 1: file size vs compression level ─────────────────────────────
fig, ax = plt.subplots(figsize=(8, 5))
ax.plot([lvl(r) for r in c_rrbs], [r["out_gib"] for r in c_rrbs],
        "o-", color="#1f77b4", linewidth=2, label="Plain (no clumpify)")
ax.plot([lvl(r) for r in b_rrbs], [r["out_gib"] for r in b_rrbs],
        "s-", color="#2ca02c", linewidth=2, label="--clumpify --memory 1G")
ax.axhline(y=RRBS_REF, color="gray", linestyle=":", alpha=0.6,
           label=f"plain c1 reference ({RRBS_REF:.2f} GiB)")
ax.set_xticks(range(1, 10))
ax.set_xlabel("--compression level")
ax.set_ylabel("Output size (GiB)")
ax.set_title("File size vs gzip level — clumpify wins at every level\n"
             "RRBS SRR24766842 (Mus musculus, MspI), --cores 8")
ax.legend(loc="upper right")
ax.grid(True, alpha=0.3)
fig.tight_layout()
fig.savefig(PLOTS / "01_filesize_vs_level.png", dpi=140)
plt.close(fig)

# ─── Plot 2: wall time vs compression level ──────────────────────────────
fig, ax = plt.subplots(figsize=(8, 5))
ax.plot([lvl(r) for r in c_rrbs], [r["wall"] for r in c_rrbs],
        "o-", color="#1f77b4", linewidth=2, label="Plain")
ax.plot([lvl(r) for r in b_rrbs], [r["wall"] for r in b_rrbs],
        "s-", color="#2ca02c", linewidth=2, label="--clumpify --memory 1G")
ax.set_xticks(range(1, 10))
ax.set_xlabel("--compression level")
ax.set_ylabel("Wall time (s)")
ax.set_title("Wall time vs gzip level — clumpify ~equivalent at low c, FASTER at high c\n"
             "(pre-sorted bins reduce deflate hash-chain work)")
ax.legend(loc="upper left")
ax.grid(True, alpha=0.3)
fig.tight_layout()
fig.savefig(PLOTS / "02_walltime_vs_level.png", dpi=140)
plt.close(fig)

# ─── Plot 3: memory sweep (Lane A) — twin axes ──────────────────────────
mem_x = [mem_ints[mem_of(r)] for r in a_rrbs]
fig, ax1 = plt.subplots(figsize=(8, 5))
color1 = "#1f77b4"
ax1.set_xlabel("--memory budget (GiB, log scale)")
ax1.set_ylabel("Wall time (s)", color=color1)
ax1.plot(mem_x, [r["wall"] for r in a_rrbs], "o-", color=color1, linewidth=2)
ax1.tick_params(axis="y", labelcolor=color1)
ax1.set_xscale("log", base=2)
ax1.set_xticks(mem_x)
ax1.set_xticklabels([f"{m}G" for m in mem_x])
ax1.grid(True, alpha=0.3)

ax2 = ax1.twinx()
color2 = "#2ca02c"
ax2.set_ylabel("Output size (GiB)", color=color2)
ax2.plot(mem_x, [r["out_gib"] for r in a_rrbs], "s--", color=color2, linewidth=2)
ax2.tick_params(axis="y", labelcolor=color2)

ax1.set_title("Memory sweep at --clumpify -c 1 — bigger budget WINS on RRBS\n"
              "(opposite direction to WGBS — see comparison plot)")
fig.tight_layout()
fig.savefig(PLOTS / "03_memory_sweep.png", dpi=140)
plt.close(fig)

# ─── Plot 4: WGBS vs RRBS comparison plot — saving vs gzip level ────────
fig, ax = plt.subplots(figsize=(9, 5.5))

# WGBS plain & clumpify
ax.plot([lvl(r) for r in c_wgbs], [r["saving_pct"] for r in c_wgbs],
        "o-", color="#1f77b4", linewidth=2, label="WGBS plain")
ax.plot([lvl(r) for r in b_wgbs], [r["saving_pct"] for r in b_wgbs],
        "s-", color="#d62728", linewidth=2, label="WGBS clumpify")
# RRBS plain & clumpify
ax.plot([lvl(r) for r in c_rrbs], [r["saving_pct"] for r in c_rrbs],
        "o-", color="#1f77b4", linewidth=2, alpha=0.4, linestyle="--", label="RRBS plain")
ax.plot([lvl(r) for r in b_rrbs], [r["saving_pct"] for r in b_rrbs],
        "s-", color="#2ca02c", linewidth=2, label="RRBS clumpify")

ax.axhline(y=0, color="gray", linestyle=":", alpha=0.5)
ax.set_xticks(range(1, 10))
ax.set_xlabel("--compression level")
ax.set_ylabel("Saving vs same-fixture plain c1 (%, +ve = smaller)")
ax.set_title("WGBS vs RRBS: clumpify regresses on WGBS, wins on RRBS\n"
             "Same flag, opposite outcome — fragment-clustering is the discriminator")
ax.legend(loc="lower right")
ax.grid(True, alpha=0.3)
fig.tight_layout()
fig.savefig(PLOTS / "04_wgbs_vs_rrbs.png", dpi=140)
plt.close(fig)

# ─── Markdown report ────────────────────────────────────────────────────
def fmt_size_table(b_lane, c_lane, ref):
    lines = ["| `-c` | Plain size (GiB) | Plain saving | Clumpify size (GiB) | Clumpify saving | Δ vs same-level plain |",
             "|---:|---:|---:|---:|---:|---:|"]
    for c in range(1, 10):
        p = next(r for r in c_lane if lvl(r) == c)
        b = next(r for r in b_lane if lvl(r) == c)
        delta = b["saving_pct"] - p["saving_pct"]
        lines.append(
            f"| {c} | {p['out_gib']:.3f} | {p['saving_pct']:+.1f}% | "
            f"{b['out_gib']:.3f} | {b['saving_pct']:+.1f}% | "
            f"**{delta:+.1f} ppt** |"
        )
    return "\n".join(lines)


def fmt_wall_table(b_lane, c_lane):
    lines = ["| `-c` | Plain wall (s) | Clumpify wall (s) | Clumpify slowdown |",
             "|---:|---:|---:|---:|"]
    for c in range(1, 10):
        p = next(r for r in c_lane if lvl(r) == c)
        b = next(r for r in b_lane if lvl(r) == c)
        slow = b["wall"] / p["wall"]
        lines.append(f"| {c} | {p['wall']:.1f} | {b['wall']:.1f} | {slow:.2f}× |")
    return "\n".join(lines)


def fmt_memory_table(a_lane):
    lines = ["| `--memory` | Wall (s) | Output (GiB) | Saving vs plain c1 | Peak RSS (MiB) | Predicted peak (MiB) |",
             "|---:|---:|---:|---:|---:|---:|"]
    for r in a_lane:
        m = mem_of(r)
        lines.append(
            f"| {m} | {r['wall']:.1f} | {r['out_gib']:.3f} | "
            f"{r['saving_pct']:+.1f}% | {r['rss_mib']:.0f} | ≈{mem_ints[m]*1024} |"
        )
    return "\n".join(lines)


def fmt_contrast_table():
    """Side-by-side WGBS vs RRBS at headline configs."""
    lines = ["| Config | WGBS Δ vs same-level plain | RRBS Δ vs same-level plain | Swing |",
             "|---|---:|---:|---:|"]
    for c in [1, 6, 9]:
        bw = next(r for r in b_wgbs if lvl(r) == c)
        cw = next(r for r in c_wgbs if lvl(r) == c)
        br = next(r for r in b_rrbs if lvl(r) == c)
        cr = next(r for r in c_rrbs if lvl(r) == c)
        wgbs_delta = bw["saving_pct"] - cw["saving_pct"]
        rrbs_delta = br["saving_pct"] - cr["saving_pct"]
        lines.append(
            f"| `--clumpify --compression {c}` | {wgbs_delta:+.1f} ppt | "
            f"{rrbs_delta:+.1f} ppt | **{rrbs_delta - wgbs_delta:+.1f} ppt** |"
        )
    # Memory swing
    wm1 = next(r for r in a_wgbs if mem_of(r) == "1G")
    wm16 = next(r for r in a_wgbs if mem_of(r) == "16G")
    rm1 = next(r for r in a_rrbs if mem_of(r) == "1G")
    rm16 = next(r for r in a_rrbs if mem_of(r) == "16G")
    wgbs_mem = wm16["saving_pct"] - wm1["saving_pct"]
    rrbs_mem = rm16["saving_pct"] - rm1["saving_pct"]
    lines.append(
        f"| `--memory 1G → 16G` (at c1) | {wgbs_mem:+.1f} ppt | "
        f"{rrbs_mem:+.1f} ppt | **{rrbs_mem - wgbs_mem:+.1f} ppt** |"
    )
    return "\n".join(lines)


def cpu_row(lane, c, label):
    r = next(rr for rr in lane if lvl(rr) == c)
    return (f"| {label} | {c} | {r['cpu_user']:.0f} | {r['cpu_sys']:.1f} | "
            f"{r['cpu_user']/r['wall']:.1f}× |")


# Memory sweep deltas
a1 = a_rrbs[0]
a16 = a_rrbs[-1]
mem_saving_swing = a16["saving_pct"] - a1["saving_pct"]
mem_wall_ratio = a16["wall"] / a1["wall"]

report = f"""# Clumpify benchmark — RRBS PE (Mus musculus, MspI)

**TL;DR:** On reduced-representation bisulfite-seq paired-end data, `--clumpify`
**wins** at every gzip level — opposite to whole-genome bisulfite-seq.
At default `--memory 1G` the win is modest (+3.5 to +5.4 ppt vs same-level
plain). The much bigger win is in the memory dial: from `--memory 1G` to
`--memory 16G` saving rises from +5.4% to +23.5% — a {mem_saving_swing:.1f} ppt
improvement, the opposite direction from WGBS.

This is the **decisive contrast** for Phil's mechanism story: clumpify
helps when biology produces fragment-level clustering (RRBS, ATAC, Ribo)
and hurts when reads are coverage-diverse (WGBS, WGS, scRNA-seq R2). MspI
restriction-enzyme cut sites concentrate reads at fragment ends; the
minimizer-driven sort co-locates reads sharing the same end, and gzip's
32 KB dictionary loves it.

## Setup

- **Host:** dockyard-oxy-0 (AL2023 x86_64, 128 cores, 991 GB RAM)
- **TG version:** 2.1.0 (Oxidized Edition), commit `3fd0454` (Phil's clumpify branch)
- **Fixture:** RRBS SRR24766842 (GSM7433400, *Mus musculus* colon, MspI-digested)
  - 102.3 M PE reads (51 bp each, vs Buckberry WGBS's 84 M at ~100-150 bp)
  - 4.4 GiB gzipped input
- **Methodology:** `hyperfine --warmup 1 --runs 1` per cell, `/usr/bin/time -v` for peak RSS
- **Fixed:** `--cores 8`, paired-end
- **Total wall:** ~2.5 hours (sentinel + 23 cells)
- **Reference:** plain `--compression 1` = **{RRBS_REF:.3f} GiB** (the 0% line)

> All sizes use **GiB** (binary, 1024³ bytes). Multiply by 1.0737 for decimal GB.

## Headline plot — WGBS vs RRBS contrast

![WGBS vs RRBS comparison](plots/04_wgbs_vs_rrbs.png)

Same flag (`--clumpify`), same code path, same compute substrate, opposite
sign on the two fixtures. The "regresses by 10–13 ppt" WGBS conclusion does
not generalise to bisulfite-seq writ large — it's specific to *coverage-diverse*
PE bisulfite data.

## Lane B vs Lane C: file-size sweep across compression levels 1–9

![File size vs level](plots/01_filesize_vs_level.png)

{fmt_size_table(b_rrbs, c_rrbs, RRBS_REF)}

The red `Δ vs same-level plain` column tracks the *additional* benefit clumpify
gives on top of plain gzip at the same level. Consistently positive (+3.5 to
+5.4 ppt) — clumpify is helping, not hurting, at every level.

The bulk of the absolute saving still comes from *gzip level alone* (Lane C
plain c9 already saves 23.7%). Clumpify adds another ~3.5–5.4 ppt on top at
default memory. The memory sweep below shows where clumpify's bigger lever lives.

## Wall time across compression levels

![Wall time vs level](plots/02_walltime_vs_level.png)

{fmt_wall_table(b_rrbs, c_rrbs)}

Notable: at c7+ clumpify is **faster** than plain (slowdown < 1.0×) — the
pre-sorted bins reduce deflate's hash-chain work, the same mechanism Phil
documented for ATAC/Ribo. So on RRBS at high compression, clumpify is a
**double win** (smaller output AND faster).

## Lane A: memory sweep at `--clumpify --compression 1`

![Memory sweep](plots/03_memory_sweep.png)

{fmt_memory_table(a_rrbs)}

**This chart sign-flips vs WGBS.** On the same 991 GB-RAM host (no page
pressure, identical compute substrate), more `--memory` makes both axes
*better* on RRBS:

- Wall time grows from {a1['wall']:.0f} s to {a16['wall']:.0f} s ({mem_wall_ratio:.1f}× — a real cost)
- Output size shrinks from {a1['out_gib']:.3f} GiB to {a16['out_gib']:.3f} GiB ({mem_saving_swing:.1f} ppt better saving)
- Peak RSS scales accurately with the budget (Phil's formula honest as ever)

So the wall-time cost from larger O(n log n) bin sorts is real on both
fixtures — but on RRBS, the bigger sort runs let the minimizer cluster
MspI-fragment-end reads tightly enough that gzip pays back the wall cost
many times over. On WGBS there's no such clustering to discover, so the
extra wall time buys nothing.

**Practical sweet spot:** at `--memory 4G` you already capture +17.8% saving
at 257 s wall — comparable to plain c9 (+23.7% at 475 s). At `--memory 16G`
you get nearly the same saving as plain c9 at 60% of the wall time.

## WGBS vs RRBS contrast — the mechanism evidence

| Config | WGBS Δ vs same-level plain | RRBS Δ vs same-level plain | Swing |
|---|---:|---:|---:|
"""

# Manual fmt_contrast_table to avoid double-formatting issue with f-string + {{}}
contrast_lines = []
for c in [1, 6, 9]:
    bw = next(r for r in b_wgbs if lvl(r) == c)
    cw = next(r for r in c_wgbs if lvl(r) == c)
    br = next(r for r in b_rrbs if lvl(r) == c)
    cr = next(r for r in c_rrbs if lvl(r) == c)
    wd = bw["saving_pct"] - cw["saving_pct"]
    rd = br["saving_pct"] - cr["saving_pct"]
    contrast_lines.append(
        f"| `--clumpify --compression {c}` | {wd:+.1f} ppt | {rd:+.1f} ppt | **{rd-wd:+.1f} ppt** |"
    )
wm1 = next(r for r in a_wgbs if mem_of(r) == "1G")
wm16 = next(r for r in a_wgbs if mem_of(r) == "16G")
rm1 = next(r for r in a_rrbs if mem_of(r) == "1G")
rm16 = next(r for r in a_rrbs if mem_of(r) == "16G")
wm = wm16["saving_pct"] - wm1["saving_pct"]
rm = rm16["saving_pct"] - rm1["saving_pct"]
contrast_lines.append(
    f"| `--memory 1G → 16G` (at c1) | {wm:+.1f} ppt | {rm:+.1f} ppt | **{rm-wm:+.1f} ppt** |"
)

report += "\n".join(contrast_lines) + f"""

The compression-level swings are ~14-16 ppt on every level — flip the
sign of the per-level Δ. The memory-axis swing is even larger (~21 ppt)
because the memory dial is what scales clumpify's bin-sort effect, and
that effect's *direction* is governed by whether the data has natural
clustering for the minimizer to find.

## Recommendation for Phil's docs (`clumpy.md`)

Phil's "When to use" table currently lumps "Bisulfite-seq / RRBS (paired)"
together with a ✅ recommendation. The data says these need to split:

| Data type | `--clumpify --compression 6` | Recommendation |
|---|---|---|
| **RRBS (paired)** | **−24% (vs plain c1)** | ✅ **Yes** — MspI-clustered fragment ends drive minimizer co-clustering. Bigger `--memory` gives substantial extra saving (+18 ppt from 1G→16G). |
| **WGBS / WGS (paired)** | **+8% (output GROWS vs plain c1)** | ❌ **No** — coverage-diverse reads, R2 disruption beats R1 win at every level. Use `--compression 6` without `--clumpify` for ~−19 % saving. |

Mechanism note: "`--clumpify` helps when biology produces fragment-level
clustering (RRBS via MspI cut sites; ATAC via Tn5 insertion bias; Ribo via
ribosome footprint stacking; amplicon via PCR redundancy) and hurts when
reads are coverage-diverse (WGS, WGBS, RNA-seq, scRNA-seq R2). The bigger
the natural cluster size, the more `--memory` budget pays off."

## CPU time

| Lane | `-c` | User CPU (s) | Sys CPU (s) | CPU/wall ratio |
|---|---:|---:|---:|---:|
{cpu_row(c_rrbs, 1, "C plain")}
{cpu_row(c_rrbs, 6, "C plain")}
{cpu_row(c_rrbs, 9, "C plain")}
{cpu_row(b_rrbs, 1, "B clumpify")}
{cpu_row(b_rrbs, 6, "B clumpify")}
{cpu_row(b_rrbs, 9, "B clumpify")}

## Raw artifacts

All 92 per-cell files (json + time.log + stdout + sizes) are at
`/tmp/claude/clumpify_rrbs_results/results/` plus `summary.csv`. Plot PNGs
are also standalone files at `/tmp/claude/clumpify_rrbs_results/plots/`.

See also: [WGBS sister report](../clumpify-buckberry-2026-05-07/) — same
matrix, opposite outcome, same code path. Direct contrast plot at
`plots/04_wgbs_vs_rrbs.png` above.
"""

(ROOT / "REPORT.md").write_text(report)
print(f"Wrote {ROOT/'REPORT.md'} ({(ROOT/'REPORT.md').stat().st_size//1024} KB)")
print(f"Plots: {len(list(PLOTS.glob('*.png')))} files in {PLOTS}/")
for p in sorted(PLOTS.glob("*.png")):
    print(f"  {p.name}: {p.stat().st_size//1024} KB")
