#!/usr/bin/env bash
# benchmark_clumpify.sh — three-lane sweep of --clumpify × --compression × --memory
# at fixed --cores 8 on the canonical Buckberry SRR24827373 paired-end fixture
# (84M PE reads, 4.6 GB gzipped — the v2.1.0-beta.7 reference dataset).
#
# Lane A (5 cells): --clumpify -c 1 --memory {1G, 2G, 4G, 8G, 16G}
#                   → tests whether 4G/8G memory blow-ups in Phil's MBP
#                     benchmarks are page-thrash artifacts that disappear
#                     on a server with 991 GB RAM
# Lane B (9 cells): --clumpify -c 1..9 --memory 1G
#                   → file size + wall as a function of gzip level WITH clumpify
# Lane C (9 cells): -c 1..9 plain (no --clumpify)
#                   → file size + wall as a function of gzip level WITHOUT clumpify
#
# Per-cell methodology: hyperfine --warmup 1 --runs 1 (output sizes are
# deterministic — no need to replicate for the headline metric; wall times
# are point estimates), with /usr/bin/time -v wrapping for peak RSS.

set -euo pipefail

# ─── Inputs ───────────────────────────────────────────────────────────────
BIN="${BIN:-$HOME/TrimGalore/target/release/trim_galore}"
R1="${R1:-$HOME/benchmark_TG_oxy/real_files/SRR24827373_GSM7445361_32F_NB3_p28_p2n2p_p10_rep1_Homo_sapiens_Bisulfite-Seq_R1.fastq.gz}"
R2="${R2:-$HOME/benchmark_TG_oxy/real_files/SRR24827373_GSM7445361_32F_NB3_p28_p2n2p_p10_rep1_Homo_sapiens_Bisulfite-Seq_R2.fastq.gz}"
WORK_ROOT="${WORK_ROOT:-$HOME/benchmark_TG_clumpify_oxy}"
RESULTS_DIR="$WORK_ROOT/results"
WARMUP="${WARMUP:-1}"
RUNS="${RUNS:-1}"
CORES="${CORES:-8}"
SENTINEL="${SENTINEL:-0}"  # if "1", run only one quick cell (plain c1) and exit

# ─── Sanity ───────────────────────────────────────────────────────────────
for tool in hyperfine /usr/bin/time gzip jq; do
    command -v "$tool" >/dev/null 2>&1 || [ -x "$tool" ] || { echo "ERROR: '$tool' not on PATH"; exit 1; }
done
[ -x "$BIN" ] || { echo "ERROR: TG binary not found at $BIN"; exit 1; }
[ -f "$R1" ] || { echo "ERROR: R1 not found at $R1"; exit 1; }
[ -f "$R2" ] || { echo "ERROR: R2 not found at $R2"; exit 1; }

mkdir -p "$RESULTS_DIR"

# Warm filesystem cache once up front so the first cell isn't penalised.
echo "Warming filesystem cache…"
cat "$R1" "$R2" > /dev/null
echo

# ─── Header ───────────────────────────────────────────────────────────────
echo "=========================================================================="
echo "Clumpify benchmark — $(date -u +%FT%TZ)"
echo "=========================================================================="
echo "Host:              $(hostname) — $(uname -srm)"
echo "TG binary:         $BIN"
echo "TG version:        $($BIN --version 2>&1 | head -1)"
echo "Provenance:        $($BIN --version 2>&1 | sed -n 2p)"
echo "Cores:             $CORES (fixed)"
echo "Hyperfine:         --warmup $WARMUP --runs $RUNS"
echo "R1:                $(basename "$R1") ($(du -h "$R1" | awk '{print $1}'))"
echo "R2:                $(basename "$R2") ($(du -h "$R2" | awk '{print $1}'))"
echo "Reads (PE):        ~84 M each (Buckberry SRR24827373)"
echo "Working dir:       $WORK_ROOT"
echo "=========================================================================="
echo

# ─── One-cell helper ──────────────────────────────────────────────────────
run_cell() {
    local label="$1"; shift
    local outdir="$WORK_ROOT/$label"
    local json="$RESULTS_DIR/${label}.json"
    local time_log="$RESULTS_DIR/${label}.time.log"
    local size_file="$RESULTS_DIR/${label}.sizes"

    mkdir -p "$outdir"

    printf '── %s ──\n' "$label"
    printf '  flags: --cores %s --paired %s\n' "$CORES" "$*"

    /usr/bin/time -v -o "$time_log" \
      hyperfine \
        --warmup "$WARMUP" --runs "$RUNS" \
        --export-json "$json" \
        --prepare "rm -rf '$outdir'/* 2>/dev/null; mkdir -p '$outdir'" \
        --command-name "$label" \
        "$BIN --cores $CORES --paired $* -o '$outdir' '$R1' '$R2'" \
        > "$RESULTS_DIR/${label}.stdout" 2>&1

    # Capture output sizes (the .fq.gz files only, not the txt reports)
    du -bc "$outdir"/*.fq.gz 2>/dev/null | tail -1 > "$size_file" || echo "0	total" > "$size_file"

    local wall_mean cpu_user cpu_sys peak_rss out_bytes
    wall_mean=$(jq -r '.results[0].mean' "$json" 2>/dev/null)
    cpu_user=$(grep "User time" "$time_log" 2>/dev/null | awk '{print $NF}')
    cpu_sys=$(grep "System time" "$time_log" 2>/dev/null | awk '{print $NF}')
    peak_rss=$(grep "Maximum resident set size" "$time_log" 2>/dev/null | awk '{print $NF}')
    out_bytes=$(awk '{print $1; exit}' "$size_file")

    printf '  wall: %.2fs  user: %ss  sys: %ss  peak_rss: %s KiB  out: %s bytes\n\n' \
      "${wall_mean:-0}" "${cpu_user:-?}" "${cpu_sys:-?}" \
      "${peak_rss:-?}" "${out_bytes:-?}"

    if [ ! -f "$RESULTS_DIR/summary.csv" ]; then
        echo "label,wall_mean_s,cpu_user_s,cpu_sys_s,peak_rss_kib,out_bytes" \
          > "$RESULTS_DIR/summary.csv"
    fi
    printf '%s,%s,%s,%s,%s,%s\n' \
      "$label" "$wall_mean" "$cpu_user" "$cpu_sys" "$peak_rss" "$out_bytes" \
      >> "$RESULTS_DIR/summary.csv"

    rm -rf "$outdir"
}

# ─── Sentinel mode: single cell + exit ───────────────────────────────────
if [ "$SENTINEL" = "1" ]; then
    echo "━━━ Sentinel: plain c1 (no --clumpify) — 1 cell only ━━━"
    run_cell "S_plain_c1_sentinel" --compression 1
    echo "Sentinel done. Inspect $RESULTS_DIR/summary.csv."
    exit 0
fi

# ─── Lane A: memory sweep at fixed --clumpify -c 1 ───────────────────────
echo "━━━ Lane A: memory sweep (--clumpify -c 1, varying --memory) — 5 cells ━━━"
for mem in 1G 2G 4G 8G 16G; do
    run_cell "A_clumpify_c1_m${mem}" --clumpify --compression 1 --memory "$mem"
done

# ─── Lane B: clumpify compression sweep at default memory ────────────────
echo "━━━ Lane B: clumpify × compression 1..9 (--memory 1G) — 9 cells ━━━"
for level in 1 2 3 4 5 6 7 8 9; do
    run_cell "B_clumpify_c${level}_m1G" --clumpify --compression "$level" --memory 1G
done

# ─── Lane C: plain compression sweep ─────────────────────────────────────
echo "━━━ Lane C: plain × compression 1..9 (no --clumpify) — 9 cells ━━━"
for level in 1 2 3 4 5 6 7 8 9; do
    run_cell "C_plain_c${level}" --compression "$level"
done

# ─── Final summary ────────────────────────────────────────────────────────
echo
echo "=========================================================================="
echo "Summary — all 23 cells complete at $(date -u +%FT%TZ)"
echo "=========================================================================="
column -t -s, "$RESULTS_DIR/summary.csv"
echo
echo "Raw artifacts: $RESULTS_DIR/"
