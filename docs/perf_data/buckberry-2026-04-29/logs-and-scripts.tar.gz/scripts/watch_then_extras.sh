#!/usr/bin/env bash
# Watcher: polls every 60s for the main tg-bench tmux session to end,
# then verifies the main wrapper's log shows a clean exit, then runs
# the extras ladder. Sequential by construction — extras only start
# after the main run has fully finished, so no concurrent trim_galore
# processes ever exist. Designed to be launched in its own tmux
# session (e.g. tg-bench-watcher).
set -uo pipefail

LOG="$HOME/bench_extras_$(date -u +%Y%m%d_%H%M%S).log"

log() {
    echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] $*" | tee -a "$LOG"
}

log "watcher started"
log "polling every 60s for tg-bench session to end..."

while tmux has-session -t tg-bench 2>/dev/null; do
    sleep 60
done

log "tg-bench session ended; verifying main run completed cleanly"

# The main wrapper's log is the most recent ~/bench_*.log that's NOT
# one of the extras logs we ourselves write here.
LATEST_MAIN_LOG=$(ls -t "$HOME"/bench_*.log 2>/dev/null | grep -v extras | head -1)
log "main log: $LATEST_MAIN_LOG"

if grep -q "Wrapper exited with benchmark.sh status=0" "$LATEST_MAIN_LOG" 2>/dev/null; then
    log "main run exited cleanly (status=0). Launching extras."
    "$HOME/run_bench_extra.sh" 2>&1 | tee -a "$LOG"
    EXTRA_STATUS=${PIPESTATUS[0]}
    log "extras exited with status=$EXTRA_STATUS"
else
    log "WARN: main run did NOT exit cleanly. Skipping extras."
    log "tail of main log:"
    tail -30 "$LATEST_MAIN_LOG" | tee -a "$LOG"
fi

log "watcher done"
