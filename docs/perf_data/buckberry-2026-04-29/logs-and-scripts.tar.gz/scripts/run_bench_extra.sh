#!/usr/bin/env bash
# Supplementary cores ladder: 10/12/14 for both Rust versions.
# Writes into ~/perf_data/2026-04-29/ alongside the main run's results
# so aggregation picks both up together. Sequential — exactly one
# trim_galore invocation runs at a time, mirroring benchmark.sh.
set -euo pipefail
export PATH="$HOME/bin:$HOME/.local/bin:$HOME/.cargo/bin:$PATH"

R1="$HOME/benchmark_TG_oxy/real_files/SRR24827373_GSM7445361_32F_NB3_p28_p2n2p_p10_rep1_Homo_sapiens_Bisulfite-Seq_R1.fastq.gz"
R2="$HOME/benchmark_TG_oxy/real_files/SRR24827373_GSM7445361_32F_NB3_p28_p2n2p_p10_rep1_Homo_sapiens_Bisulfite-Seq_R2.fastq.gz"

RUST_BETA5="$HOME/.cargo-tg-beta5/bin/trim_galore"
RUST_BETA7="$HOME/.cargo-tg-beta7/bin/trim_galore"

WORK_ROOT="/tmp/tg_bench"
RESULTS_DIR="$HOME/perf_data/2026-04-29"
WARMUP=1
RUNS=10
EXTRA_CORES="10 12 14"

mkdir -p "$WORK_ROOT" "$RESULTS_DIR"

run_sweep() {
    local label="$1"; shift
    local cores="$1"; shift
    local cmd_template="$1"; shift

    local outdir="$WORK_ROOT/${label}_c${cores}"
    local json="$RESULTS_DIR/${label}_c${cores}.json"
    local md="$RESULTS_DIR/${label}_c${cores}.md"

    echo "----- ${label} cores=${cores} -----"
    rm -rf "$outdir"
    mkdir -p "$outdir"

    local cmd="${cmd_template//\{outdir\}/$outdir}"
    cmd="${cmd//\{cores\}/$cores}"

    hyperfine \
        --warmup "$WARMUP" \
        --runs "$RUNS" \
        --prepare "rm -rf $outdir && mkdir -p $outdir" \
        --command-name "${label}-c${cores}" \
        --export-json "$json" \
        --export-markdown "$md" \
        "$cmd"
    echo ""
}

echo "================================================================"
echo "Trim Galore extras — cores 10/12/14 for both Rust versions"
echo "Started at $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "Hardware: $(hostname) — $(nproc) cores"
echo "================================================================"

echo "[A/2] Rust v2.1.0-beta.5 (extras: cores $EXTRA_CORES)"
for c in $EXTRA_CORES; do
    run_sweep "rust-beta5" "$c" "$RUST_BETA5 --paired --cores {cores} -o {outdir} $R1 $R2"
done

echo "[B/2] Rust v2.1.0-beta.7 (extras: cores $EXTRA_CORES)"
for c in $EXTRA_CORES; do
    run_sweep "rust-beta7" "$c" "$RUST_BETA7 --paired --cores {cores} -o {outdir} $R1 $R2"
done

echo "================================================================"
echo "Extras done at $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "================================================================"
