#!/usr/bin/env bash
# Wrapper for tmux-detached benchmark runs.
# Sets PATH so hyperfine/cutadapt/cargo are visible inside tmux's
# environment, points benchmark.sh at the canonical-named local copy
# of the Buckberry SRR24827373 fixture, tees output to a timestamped
# log in $HOME.
set -uo pipefail
export PATH="$HOME/bin:$HOME/.local/bin:$HOME/.cargo/bin:$PATH"

LOG="$HOME/bench_$(date -u +%Y%m%d_%H%M%S).log"
R1_PATH="$HOME/benchmark_TG_oxy/real_files/SRR24827373_GSM7445361_32F_NB3_p28_p2n2p_p10_rep1_Homo_sapiens_Bisulfite-Seq_R1.fastq.gz"
R2_PATH="$HOME/benchmark_TG_oxy/real_files/SRR24827373_GSM7445361_32F_NB3_p28_p2n2p_p10_rep1_Homo_sapiens_Bisulfite-Seq_R2.fastq.gz"

echo "================================================================"
echo "Trim Galore Buckberry-scale benchmark"
echo "Wrapper started at $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "Log: $LOG"
echo "Fixture R1: $R1_PATH"
echo "Fixture R2: $R2_PATH"
echo "================================================================"

cd "$HOME"
R1="$R1_PATH" R2="$R2_PATH" bash ./benchmark.sh 2>&1 | tee "$LOG"

EXIT_STATUS=${PIPESTATUS[0]}
echo "================================================================"
echo "Wrapper exited with benchmark.sh status=$EXIT_STATUS at $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "================================================================"
