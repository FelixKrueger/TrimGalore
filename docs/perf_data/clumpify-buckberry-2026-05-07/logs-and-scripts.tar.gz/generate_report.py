#!/usr/bin/env python3
"""
Generate clumpify benchmark report on Buckberry SRR24827373 WGBS PE.

Inputs:  /tmp/claude/clumpify_results/results/summary.csv
Outputs: /tmp/claude/clumpify_results/REPORT.md  (with base64-inlined plots)
         /tmp/claude/clumpify_results/plots/*.png
"""
import os
import re
import csv
import base64
from pathlib import Path
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path("/tmp/claude/clumpify_results")
RESULTS = ROOT / "results"
PLOTS = ROOT / "plots"
PLOTS.mkdir(exist_ok=True)

# INLINE_PLOTS=1 → base64-embedded data URIs (self-contained MD).
# INLINE_PLOTS=0 → relative paths "plots/<name>" (smaller, version-friendly,
#                  but plots/ must travel with the .md).
INLINE_PLOTS = os.environ.get("INLINE_PLOTS", "1") == "1"


def img(name, alt):
    if INLINE_PLOTS:
        data = (PLOTS / name).read_bytes()
        b64 = base64.b64encode(data).decode("ascii")
        return f"![{alt}](data:image/png;base64,{b64})"
    return f"![{alt}](plots/{name})"


# ─── Load summary.csv ────────────────────────────────────────────────────
rows = []
with open(RESULTS / "summary.csv") as f:
    for r in csv.DictReader(f):
        r["wall"] = float(r["wall_mean_s"])
        r["cpu_user"] = float(r["cpu_user_s"])
        r["cpu_sys"] = float(r["cpu_sys_s"])
        r["rss_mib"] = float(r["peak_rss_kib"]) / 1024.0
        r["out_gib"] = float(r["out_bytes"]) / (1024**3)
        rows.append(r)

# Reference: plain c1 in GiB
REF_GIB = next(r for r in rows if r["label"] == "C_plain_c1")["out_gib"]
for r in rows:
    r["saving_pct"] = (REF_GIB - r["out_gib"]) / REF_GIB * 100  # +ve = smaller


def by_prefix(prefix):
    return [r for r in rows if r["label"].startswith(prefix)]


def level_of(r):
    m = re.search(r"_c(\d+)(?:_|$)", r["label"])
    return int(m.group(1)) if m else None


def mem_of(r):
    m = re.search(r"_m(\d+G)$", r["label"])
    return m.group(1) if m else None


lane_b = sorted([r for r in by_prefix("B_clumpify_") if "_c" in r["label"]], key=level_of)
lane_c = sorted(by_prefix("C_plain_"), key=level_of)
mem_order = ["1G", "2G", "4G", "8G", "16G"]
mem_ints = {"1G": 1, "2G": 2, "4G": 4, "8G": 8, "16G": 16}
lane_a = sorted(by_prefix("A_clumpify_c1_"), key=lambda r: mem_order.index(mem_of(r)))


# ─── Plot 1: file size vs compression level ─────────────────────────────
fig, ax = plt.subplots(figsize=(8, 5))
ax.plot([level_of(r) for r in lane_c], [r["out_gib"] for r in lane_c],
        "o-", color="#1f77b4", linewidth=2, label="Plain (no clumpify)")
ax.plot([level_of(r) for r in lane_b], [r["out_gib"] for r in lane_b],
        "s-", color="#d62728", linewidth=2, label="--clumpify --memory 1G")
ax.axhline(y=REF_GIB, color="gray", linestyle=":", alpha=0.6,
           label=f"plain c1 reference ({REF_GIB:.2f} GiB)")
ax.set_xticks(range(1, 10))
ax.set_xlabel("--compression level")
ax.set_ylabel("Output size (GiB)")
ax.set_title("File size vs gzip level — clumpify regresses at every level\n"
             "Buckberry SRR24827373 WGBS PE, --cores 8")
ax.legend(loc="upper right")
ax.grid(True, alpha=0.3)
fig.tight_layout()
fig.savefig(PLOTS / "01_filesize_vs_level.png", dpi=140)
plt.close(fig)


# ─── Plot 2: wall time vs compression level ──────────────────────────────
fig, ax = plt.subplots(figsize=(8, 5))
ax.plot([level_of(r) for r in lane_c], [r["wall"] for r in lane_c],
        "o-", color="#1f77b4", linewidth=2, label="Plain")
ax.plot([level_of(r) for r in lane_b], [r["wall"] for r in lane_b],
        "s-", color="#d62728", linewidth=2, label="--clumpify --memory 1G")
ax.set_xticks(range(1, 10))
ax.set_xlabel("--compression level")
ax.set_ylabel("Wall time (s)")
ax.set_title("Wall time vs gzip level — both grow super-linearly past c5\n"
             "Buckberry SRR24827373 WGBS PE, --cores 8")
ax.legend(loc="upper left")
ax.grid(True, alpha=0.3)
fig.tight_layout()
fig.savefig(PLOTS / "02_walltime_vs_level.png", dpi=140)
plt.close(fig)


# ─── Plot 3: memory sweep (Lane A) — twin axes ──────────────────────────
mem_x = [mem_ints[mem_of(r)] for r in lane_a]
fig, ax1 = plt.subplots(figsize=(8, 5))
color1 = "#1f77b4"
ax1.set_xlabel("--memory budget (GiB, log scale)")
ax1.set_ylabel("Wall time (s)", color=color1)
ax1.plot(mem_x, [r["wall"] for r in lane_a], "o-", color=color1, linewidth=2)
ax1.tick_params(axis="y", labelcolor=color1)
ax1.set_xscale("log", base=2)
ax1.set_xticks(mem_x)
ax1.set_xticklabels([f"{m}G" for m in mem_x])
ax1.grid(True, alpha=0.3)

ax2 = ax1.twinx()
color2 = "#d62728"
ax2.set_ylabel("Output size (GiB)", color=color2)
ax2.plot(mem_x, [r["out_gib"] for r in lane_a], "s--", color=color2, linewidth=2)
ax2.tick_params(axis="y", labelcolor=color2)

ax1.set_title("Memory sweep at --clumpify -c 1 — bigger budget hurts both axes\n"
              "Buckberry WGBS PE on 991 GB-RAM host (no page-thrash)")
fig.tight_layout()
fig.savefig(PLOTS / "03_memory_sweep.png", dpi=140)
plt.close(fig)


# ─── Plot 4: scatter — saving (%) vs wall time ──────────────────────────
fig, ax = plt.subplots(figsize=(8.5, 5.5))
ax.scatter([r["wall"] for r in lane_a], [r["saving_pct"] for r in lane_a],
           color="#2ca02c", s=80, alpha=0.85, marker="^",
           label="Lane A: clumpify c1, mem sweep")
ax.scatter([r["wall"] for r in lane_b], [r["saving_pct"] for r in lane_b],
           color="#d62728", s=80, alpha=0.85, marker="s",
           label="Lane B: clumpify, c=1..9")
ax.scatter([r["wall"] for r in lane_c], [r["saving_pct"] for r in lane_c],
           color="#1f77b4", s=80, alpha=0.85, marker="o",
           label="Lane C: plain, c=1..9")

for r in lane_b:
    ax.annotate(f"c{level_of(r)}", (r["wall"], r["saving_pct"]),
                xytext=(6, 4), textcoords="offset points", fontsize=8, color="#a01a1a")
for r in lane_c:
    ax.annotate(f"c{level_of(r)}", (r["wall"], r["saving_pct"]),
                xytext=(6, -10), textcoords="offset points", fontsize=8, color="#0a4a8a")
for r in lane_a:
    ax.annotate(mem_of(r), (r["wall"], r["saving_pct"]),
                xytext=(-22, -10), textcoords="offset points", fontsize=8, color="#0d5a0d")

ax.axhline(y=0, color="gray", linestyle=":", alpha=0.5)
ax.set_xlabel("Wall time (s)")
ax.set_ylabel("File-size saving vs plain c1 (%, +ve = smaller)")
ax.set_title("Pareto: saving vs wall time (all 23 cells)\n"
             "Clumpify line sits below the plain line at every comparable wall budget")
ax.legend(loc="upper left")
ax.grid(True, alpha=0.3)
fig.tight_layout()
fig.savefig(PLOTS / "04_pareto_saving_vs_wall.png", dpi=140)
plt.close(fig)


# ─── Markdown report (with inlined plots) ───────────────────────────────
def fmt_size_table():
    lines = ["| `-c` | Plain size (GiB) | Plain saving | Clumpify size (GiB) | Clumpify saving | Δ vs same-level plain |",
             "|---:|---:|---:|---:|---:|---:|"]
    for c in range(1, 10):
        p = next(r for r in lane_c if level_of(r) == c)
        b = next(r for r in lane_b if level_of(r) == c)
        delta_ppt = b["saving_pct"] - p["saving_pct"]
        lines.append(
            f"| {c} | {p['out_gib']:.3f} | {p['saving_pct']:+.1f}% | "
            f"{b['out_gib']:.3f} | {b['saving_pct']:+.1f}% | "
            f"**{delta_ppt:+.1f} ppt** |"
        )
    return "\n".join(lines)


def fmt_wall_table():
    lines = ["| `-c` | Plain wall (s) | Clumpify wall (s) | Clumpify slowdown |",
             "|---:|---:|---:|---:|"]
    for c in range(1, 10):
        p = next(r for r in lane_c if level_of(r) == c)
        b = next(r for r in lane_b if level_of(r) == c)
        slow = b["wall"] / p["wall"]
        lines.append(f"| {c} | {p['wall']:.1f} | {b['wall']:.1f} | {slow:.2f}× |")
    return "\n".join(lines)


def fmt_memory_table():
    lines = ["| `--memory` | Wall (s) | Output (GiB) | Saving vs plain c1 | Peak RSS (MiB) | Predicted peak (MiB) |",
             "|---:|---:|---:|---:|---:|---:|"]
    for r in lane_a:
        m = mem_of(r)
        lines.append(
            f"| {m} | {r['wall']:.1f} | {r['out_gib']:.3f} | "
            f"{r['saving_pct']:+.1f}% | {r['rss_mib']:.0f} | ≈{mem_ints[m]*1024} |"
        )
    return "\n".join(lines)


def cpu_row(lane, c, label):
    r = next(rr for rr in lane if level_of(rr) == c)
    return (f"| {label} | {c} | {r['cpu_user']:.0f} | {r['cpu_sys']:.1f} | "
            f"{r['cpu_user']/r['wall']:.1f}× |")


# Lane A delta for the prose under the memory chart
mem_first = lane_a[0]
mem_last = lane_a[-1]
lane_a_saving_delta = mem_first["saving_pct"] - mem_last["saving_pct"]  # +ve = got worse

report = f"""# Clumpify benchmark — Buckberry SRR24827373 WGBS PE

**TL;DR:** On whole-genome bisulfite-seq paired-end data, `--clumpify` makes
output **bigger** at every gzip level (~10–13 ppt worse than plain at the
same `-c`). Larger `--memory` budgets do not recover the loss — they make
both wall time and output size slightly worse, ruling out 16 GiB-host
page-thrash as the explanation. The R2-disruption mechanism Phil isolated
for 10x scRNA-seq generalises here: paired-end data where R1 isn't tightly
peak-clustered hurts R2 by forcing pair-lockstep ordering.

## Setup

- **Host:** dockyard-oxy-0 (AL2023 x86_64, 128 cores, 991 GB RAM)
- **TG version:** 2.1.0 (Oxidized Edition), commit `3fd0454` (Phil's clumpify branch)
- **Fixture:** Buckberry SRR24827373 WGBS, ~84M PE reads, 4.6 GiB gzipped
- **Methodology:** `hyperfine --warmup 1 --runs 1` per cell, `/usr/bin/time -v` for peak RSS
- **Fixed:** `--cores 8`, paired-end
- **Total wall:** 2 h 42 min (sentinel + 23 cells)
- **Reference:** plain `--compression 1` = **{REF_GIB:.3f} GiB** (the 0% line)

> All sizes in this report use **GiB** (binary, 1024³ bytes) for consistency
> with the source byte counts. Multiply by 1.0737 for decimal GB.

## Headline plot

{img("04_pareto_saving_vs_wall.png", "Pareto saving vs wall")}

The plain line (blue) dominates the clumpify line (red) at every wall
budget — there is no clumpify configuration that saves more disk than
plain at the same wall time. (Lane A, green triangles, adds memory
budget as a third axis but stays in the negative-saving quadrant
throughout.)

## Lane B vs Lane C: file-size sweep across compression levels 1–9

{img("01_filesize_vs_level.png", "File size vs level")}

{fmt_size_table()}

The "Δ vs same-level plain" column is the cost of `--clumpify` in
percentage points of saving against plain at the same `--compression`:
clumpify never wins on this data, with a flat ~10–13 ppt penalty across
the entire sweep.

## Wall time across compression levels

{img("02_walltime_vs_level.png", "Wall time vs level")}

{fmt_wall_table()}

c1–c4 are dominated by trim+I/O cost (mostly flat); past c5 gzip CPU
takes over. Clumpify adds ~30–40 % overhead at low levels (consistent
with Phil's "1.0–1.4× plain" claim on data types that compress well —
but here the overhead is wasted because the resulting bytes are bigger).
At c7+ the clumpify "slowdown" actually flips to a small speedup,
because pre-sorted bins reduce deflate hash-chain work — the same
mechanism Phil noted for ATAC/Ribo, just not enough to offset the size
penalty.

## Lane A: memory sweep at `--clumpify --compression 1`

{img("03_memory_sweep.png", "Memory sweep")}

{fmt_memory_table()}

**This is the most decisive single chart.** On a 991 GB-RAM host (no page
pressure), more `--memory` makes both axes worse:

- Wall time grows from {mem_first['wall']:.0f} s to {mem_last['wall']:.0f} s ({mem_last['wall']/mem_first['wall']:.1f}× slower at 16G vs 1G)
- Output size grows from {mem_first['out_gib']:.3f} GiB to {mem_last['out_gib']:.3f} GiB ({lane_a_saving_delta:.1f} ppt worse saving)
- Peak RSS scales accurately with the budget (Phil's formula is honest)

The wall-time blow-ups Phil observed at 4G/8G on his 16 GiB MBP are
**not** purely page-thrash artefacts — even with 991 GB headroom, larger
bins cost more wall time (bigger O(n log n) sorts per bin). They were
likely page-thrash *amplified* on his hardware, but the underlying cost
exists regardless.

## Why clumpify regresses on WGBS PE (hypothesis)

Same R2-disruption mechanism Phil documented for 10x scRNA-seq, applied
more broadly:

1. **WGBS R1 reads are coverage-diverse, not peak-clustered.** Bisulfite
   alphabet-collapse (C → T at unmethylated positions) gives gzip *some*
   per-read redundancy, but the minimizer doesn't find tight clusters —
   genome-wide ~30× coverage spreads minimizer keys broadly.
2. **R2 follows R1's sorted order to preserve pair lockstep**, scrambling
   R2's natural flowcell-cluster ordering (which gzip on the unsorted
   plain stream was happily exploiting).
3. **The R2 disruption beats any R1 win at every gzip level.** The flat
   ~10–13 ppt regression across c=1..9 confirms that larger gzip
   dictionaries don't recover the lost R2 locality — the reordering
   inflicts a structural penalty, not just a header-overhead one.

ATAC-seq and Ribo-seq escape this regression because Tn5 / ribosome
biology produces *fragment-level* clustering — both R1 and R2 of a
clustered fragment land together naturally, so pair-lockstep doesn't
hurt. WGBS, WGS, RNA-seq, and 10x are all candidates for the same
regression; only WGBS is in this benchmark.

## CPU time

| Lane | `-c` | User CPU (s) | Sys CPU (s) | CPU/wall ratio |
|---|---:|---:|---:|---:|
{cpu_row(lane_c, 1, "C plain")}
{cpu_row(lane_c, 6, "C plain")}
{cpu_row(lane_c, 9, "C plain")}
{cpu_row(lane_b, 1, "B clumpify")}
{cpu_row(lane_b, 6, "B clumpify")}
{cpu_row(lane_b, 9, "B clumpify")}

System CPU stays under 16 s for every cell (no I/O wait, no page
thrash). User-CPU/wall ratios above 12 reflect the N+4 thread model
plus the bin-sort dispatcher overlap.

## Recommendation for Phil's docs

Add a row to the "When to use" table:

| Data type | Saving (`--clumpify --compression 6`) | Recommendation |
|---|---|---|
| **WGBS / WGS (paired)** | **negative — output grows** | ❌ **No** — same R2-disruption mechanism as 10x scRNA-seq. Use `--compression 6` without `--clumpify` for ~−19 % saving. |

Possible mechanism note in the regression caveat: "paired-end libraries
where neither read is tightly peak-clustered (whole-genome coverage,
single-cell barcode + cDNA) regress under `--clumpify` because R2 is
forced to follow R1's minimizer order and loses its natural flowcell-
cluster locality."

## Raw artifacts

All 92 per-cell files (json + time.log + stdout + sizes) are at
`/tmp/claude/clumpify_results/results/` plus `summary.csv`. Plot PNGs
also exist as standalone files at `/tmp/claude/clumpify_results/plots/`
in addition to being inlined above.
"""

(ROOT / "REPORT.md").write_text(report)
print(f"Wrote {ROOT/'REPORT.md'} ({(ROOT/'REPORT.md').stat().st_size//1024} KB)")
print(f"Plots: {len(list(PLOTS.glob('*.png')))} files in {PLOTS}/")
for p in sorted(PLOTS.glob("*.png")):
    print(f"  {p.name}: {p.stat().st_size//1024} KB")
